package org.ebayopensource.fido.uaf.msg;

public class TrustedFacetsList {
    private TrustedFacets[] trustedFacets;

    public TrustedFacetsList(){

    }

    public TrustedFacets[] getTrustedFacets() {
        return trustedFacets;
    }
}
